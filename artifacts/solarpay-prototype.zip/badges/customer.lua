--[==[badge-app
slug=solarpay_customer
name=SolarPay Customer
icon=SOL
api=2
heap_kb=48
wake_lock=1
version=0.1.0
]==]

local profile_badge_id = "__SOLARPAY_BADGE_ID__"
local wallet_address = "__SOLARPAY_WALLET_ADDRESS__"
local radio_ok = false
local pending_id, pending_nonce, pending_amount, deadline
local status, amount, hint, wallet

local function short_address(value)
  if not value or #value < 18 or string.sub(value, 1, 2) == "__" then return "Profile not linked" end
  return string.sub(value, 1, 8) .. "..." .. string.sub(value, -8)
end

local function set_leds(r, g, b)
  badge.led.clear()
  for i = 1, 6 do badge.led.set(i, r, g, b) end
  badge.led.show()
end

function on_enter(root)
  local linked_id = profile_badge_id
  if string.sub(linked_id, 1, 2) == "__" then linked_id = badge.me.badge_id() or "unprovisioned" end
  badge.sys.log("SOLARPAY_BADGE:customer:" .. linked_id)
  local title = badge.ui.label(root, "SolarPay")
  title:align("top_mid", 0, 18)
  wallet = badge.ui.label(root, short_address(wallet_address))
  wallet:style({text_font = 14})
  wallet:align("top_mid", 0, 46)
  status = badge.ui.label(root, "Looking for a terminal...")
  status:style({text_font = 14})
  status:align("center", 0, -34)
  amount = badge.ui.label(root, "No payment")
  amount:align("center", 0, 0)
  hint = badge.ui.label(root, "HOME exit")
  hint:style({text_font = 14})
  hint:align("bottom_mid", 0, -18)
  radio_ok = badge.radio.enable()
  if not radio_ok then status:set_text("Radio unavailable"); set_leds(120, 20, 10); return end
  set_leds(0, 22, 14)
  badge.radio.on_recv(function(_, _, payload)
    local id, lamports, ttl, nonce, merchant = string.match(payload, "^SP1:I:([0-9a-f]+):(%d+):(%d+):([0-9a-f]+):([A-Za-z0-9_-]+)$")
    if not id then return end
    pending_id = id
    pending_nonce = nonce
    pending_amount = tonumber(lamports)
    deadline = badge.sys.ms() + math.min(tonumber(ttl), 90) * 1000
    status:set_text("Merchant " .. merchant .. " requests")
    amount:set_text(string.format("%.4f SOL", pending_amount / 1000000000))
    hint:set_text("A approve   B decline   HOME exit")
    set_leds(18, 105, 60)
  end)
end

function on_tick()
  if pending_id and badge.sys.ms() >= deadline then
    pending_id = nil; pending_nonce = nil
    status:set_text("Payment expired")
    amount:set_text("No payment")
    hint:set_text("HOME exit")
    set_leds(90, 45, 0)
  end
end

function on_button(button, kind)
  if kind ~= badge.input.KIND.PRESSED or not pending_id then return end
  if button == badge.input.BUTTON.B then
    pending_id = nil; pending_nonce = nil; status:set_text("Declined"); amount:set_text("No payment"); hint:set_text("HOME exit"); set_leds(70, 15, 10); return
  end
  if button ~= badge.input.BUTTON.A then return end
  local id = profile_badge_id
  if string.sub(id, 1, 2) == "__" then id = badge.me.badge_id() end
  if not id or #id > 16 then status:set_text("Badge ID unavailable"); return end
  local packet = "SP1:A:" .. pending_id .. ":" .. id .. ":" .. pending_nonce
  if #packet > 44 then status:set_text("Badge ID too long"); return end
  if badge.radio.send(packet) then
    status:set_text("Approval sent")
    amount:set_text("Waiting for terminal")
    hint:set_text("HOME exit")
    set_leds(0, 180, 75)
    pending_id = nil; pending_nonce = nil
  else status:set_text("Send failed - press A") end
end

function on_exit()
  badge.led.clear(); badge.led.show()
  if radio_ok then badge.radio.on_recv(nil); badge.radio.disable() end
end
