--[==[badge-app
slug=solarpay_terminal
name=SolarPay Terminal
icon=PAY
api=2
heap_kb=48
wake_lock=1
version=0.1.0
]==]

local profile_badge_id = "__SOLARPAY_BADGE_ID__"
local wallet_address = "__SOLARPAY_WALLET_ADDRESS__"

-- Radio hardware demo. A broadcasts a test payment. Approvals are logged to
-- USB serial for the laptop to observe. The documented badge API has no USB RX.
local radio_ok = false
local active_id, active_nonce = nil, nil
local expires_at = 0
local status, detail

local function set_leds(r, g, b)
  badge.led.clear()
  for i = 1, 6 do badge.led.set(i, r, g, b) end
  badge.led.show()
end

local function broadcast_test()
  active_id = string.format("%08x", badge.sys.random())
  active_nonce = string.sub(string.format("%08x%08x", badge.sys.random(), badge.sys.random()), 1, 11)
  expires_at = badge.sys.ms() + 90000
  local packet = "SP1:I:" .. active_id .. ":10000000:90:" .. active_nonce .. ":SH"
  if badge.radio.send(packet) then
    status:set_text("Payment broadcast")
    detail:set_text("0.0100 SOL  •  " .. active_id)
    set_leds(20, 110, 62)
  else
    status:set_text("Broadcast failed")
    set_leds(130, 20, 10)
  end
end

function on_enter(root)
  local linked_id = profile_badge_id
  if string.sub(linked_id, 1, 2) == "__" then linked_id = badge.me.badge_id() or "unprovisioned" end
  badge.sys.log("SOLARPAY_BADGE:merchant:" .. linked_id)
  local title = badge.ui.label(root, "SolarPay Terminal")
  title:align("top_mid", 0, 18)
  status = badge.ui.label(root, "Starting radio...")
  status:align("center", 0, -22)
  detail = badge.ui.label(root, "A sends a test payment")
  detail:style({text_font = 14})
  detail:align("center", 0, 12)
  local hint = badge.ui.label(root, "A broadcast   B cancel   HOME exit")
  hint:style({text_font = 14})
  hint:align("bottom_mid", 0, -18)
  radio_ok = badge.radio.enable()
  if not radio_ok then status:set_text("Radio unavailable"); set_leds(120, 20, 10); return end
  status:set_text("Ready")
  set_leds(0, 35, 18)
  badge.radio.on_recv(function(_, _, payload)
    if not active_id or badge.sys.ms() >= expires_at then return end
    local prefix = "SP1:A:" .. active_id .. ":"
    if string.sub(payload, 1, #prefix) ~= prefix then return end
    status:set_text("Customer approved")
    detail:set_text("Relayed to laptop over serial")
    badge.sys.log("SOLARPAY_APPROVAL:" .. payload)
    set_leds(0, 180, 75)
    active_id = nil; active_nonce = nil
  end)
end

function on_tick()
  if active_id and badge.sys.ms() >= expires_at then
    active_id = nil; active_nonce = nil
    status:set_text("Payment expired")
    detail:set_text("Press A to try again")
    set_leds(100, 45, 0)
  end
end

function on_button(button, kind)
  if kind ~= badge.input.KIND.PRESSED or not radio_ok then return end
  if button == badge.input.BUTTON.A then broadcast_test() end
  if button == badge.input.BUTTON.B then active_id = nil; active_nonce = nil; status:set_text("Cancelled"); detail:set_text("Press A for a new payment"); set_leds(0, 35, 18) end
end

function on_exit()
  badge.led.clear(); badge.led.show()
  if radio_ok then badge.radio.on_recv(nil); badge.radio.disable() end
end
