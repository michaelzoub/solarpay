import test from "node:test";
import assert from "node:assert/strict";
import { MockCustomerBadge, MockRadio, MockTerminalSerial } from "../server/mock-adapters.js";
import { intentPacket } from "../server/protocol.js";

test("mock USB and radio adapters carry an end-to-end badge approval", async () => {
  const radio = new MockRadio();
  const terminal = new MockTerminalSerial("TERM-001", radio);
  const customer = new MockCustomerBadge("CUST-001", radio);
  radio.on("packet", (packet) => {
    if (packet.startsWith("SP1:A:")) terminal.relayApproval(packet);
  });

  const displayed = new Promise((resolve) => customer.once("display", resolve));
  const relayed = new Promise((resolve) => terminal.once("approval", resolve));
  terminal.sendIntent(intentPacket({ id: "01234567", amount_lamports: 50_000_000, intent_nonce: "deadbeef123" }, 90));
  assert.equal((await displayed).amountLamports, 50_000_000);
  customer.pressA();
  const approval = await relayed;
  assert.equal(approval.intentId, "01234567");
  assert.equal(approval.customerBadgeId, "CUST-001");
  assert.equal(approval.nonce, "deadbeef123");
});
