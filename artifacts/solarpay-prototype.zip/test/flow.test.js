import test from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import { createApp } from "../server/app.js";
import { Store } from "../server/db.js";
import { MockSolana } from "../server/solana.js";

function fixture(ttl = 90_000) {
  const store = new Store(":memory:", Buffer.alloc(32, 7).toString("base64"));
  const solana = new MockSolana();
  const config = { apiKeys: new Map([["laptop-secret", "laptop-1"], ["other-secret", "laptop-2"]]), adminApiKey: "admin-secret", solanaMode: "mock", intentTtlSeconds: ttl / 1000 };
  const app = createApp({ config, store, solana });
  const merchant = solana.generateWallet();
  const customer = solana.generateWallet();
  store.registerBadge({ badgeId: "TERM-001", role: "merchant", ...merchant });
  store.registerBadge({ badgeId: "CUST-001", role: "customer", ...customer });
  solana.fund(customer.publicKey, 2_000_000_000);
  return { app, store, solana, merchant, customer };
}

const auth = { authorization: "Bearer laptop-secret" };

test("guided setup creates a badge profile and serves its installable app", async (t) => {
  const f = fixture(); t.after(() => f.store.close());
  const created = await request(f.app).post("/api/badges").set(auth).send({ role: "customer" }).expect(201);
  assert.match(created.body.badgeId, /^PAY-[0-9A-F]{6}$/);
  const badges = await request(f.app).get("/api/badges").set(auth).expect(200);
  assert.ok(badges.body.badges.some((badge) => badge.badgeId === created.body.badgeId));
  const appFile = await request(f.app).get("/api/badge-apps/customer").expect(200);
  assert.match(appFile.text, /slug=solarpay_customer/);
  assert.match(appFile.headers["content-disposition"], /solarpay-customer\.lua/);
  const personalized = await request(f.app).get(`/api/badges/${created.body.badgeId}/app`).set(auth).expect(200);
  assert.match(personalized.text, new RegExp(created.body.badgeId));
  assert.match(personalized.text, new RegExp(created.body.publicKey));
  assert.doesNotMatch(personalized.text, /__SOLARPAY_WALLET_ADDRESS__/);
});

test("diagnostics export is useful and excludes sensitive wallet data", async (t) => {
  const f = fixture(); t.after(() => f.store.close());
  const response = await request(f.app).get("/api/diagnostics").set(auth).expect(200);
  assert.equal(response.body.solanaMode, "mock");
  assert.equal(response.body.database.badges.merchant, 1);
  assert.equal(response.body.database.badges.customer, 1);
  assert.deepEqual(response.body.database.migrations.map((migration) => migration.version), [1, 2]);
  const serialized = JSON.stringify(response.body);
  assert.doesNotMatch(serialized, new RegExp(f.customer.secretKey.slice(0, 12)));
  assert.doesNotMatch(serialized, new RegExp(f.customer.publicKey));
});

test("admin can create and list badge-to-address mappings", async (t) => {
  const f = fixture(); t.after(() => f.store.close());
  const merchantAddress = f.solana.generateWallet().publicKey;
  const created = await request(f.app).post("/api/admin/badges").set("x-admin-key", "admin-secret")
    .send({ badgeId: "SHOP-002", role: "merchant", solanaAddress: merchantAddress }).expect(201);
  assert.equal(created.body.publicKey, merchantAddress);
  assert.equal(created.body.secretKey, undefined);
  const payer = await request(f.app).post("/api/admin/badges").set("x-admin-key", "admin-secret")
    .send({ badgeId: "PAY-002", role: "customer" }).expect(201);
  assert.ok(payer.body.publicKey);
  const listed = await request(f.app).get("/api/admin/badges").set("x-admin-key", "admin-secret").expect(200);
  assert.ok(listed.body.badges.some((badge) => badge.badgeId === "SHOP-002" && badge.solanaAddress === merchantAddress));
  assert.ok(listed.body.badges.some((badge) => badge.badgeId === "PAY-002"));
  const balance = await request(f.app).get("/api/admin/badges/PAY-002/balance").set("x-admin-key", "admin-secret").expect(200);
  assert.equal(balance.body.role, "customer");
  assert.equal(balance.body.lamports, 10_000_000_000);
});

test("complete payment signs on backend and confirms through laptop submit", async (t) => {
  const f = fixture(); t.after(() => f.store.close());
  const created = await request(f.app).post("/api/intents").set(auth).send({ terminalBadgeId: "TERM-001", amountLamports: 25_000_000, memo: "Lunch" }).expect(201);
  assert.equal(created.body.status, "pending");
  assert.ok(created.body.radioPacket.startsWith("SP1:I:"));
  assert.equal(created.body.protocolVersion, 1);
  assert.match(created.body.intentNonce, /^[A-Za-z0-9_-]{11}$/);
  const approved = await request(f.app).post(`/api/intents/${created.body.id}/approve`).set(auth).send({ customerBadgeId: "CUST-001", intentNonce: created.body.intentNonce }).expect(200);
  assert.ok(approved.body.signedTransaction.rawTransaction);
  const submitted = await request(f.app).post(`/api/intents/${created.body.id}/submit`).set(auth).send({ signedTransaction: approved.body.signedTransaction }).expect(200);
  assert.equal(submitted.body.intent.status, "confirmed");
  assert.equal(f.solana.balances.get(f.merchant.publicKey), 25_000_000);
});

test("duplicate approvals and invalid intent nonces are rejected", async (t) => {
  const f = fixture(); t.after(() => f.store.close());
  const first = await request(f.app).post("/api/intents").set(auth).send({ terminalBadgeId: "TERM-001", amountLamports: 1 }).expect(201);
  await request(f.app).post(`/api/intents/${first.body.id}/approve`).set(auth).send({ customerBadgeId: "CUST-001", intentNonce: first.body.intentNonce }).expect(200);
  const duplicate = await request(f.app).post(`/api/intents/${first.body.id}/approve`).set(auth).send({ customerBadgeId: "CUST-001", intentNonce: first.body.intentNonce }).expect(409);
  assert.equal(duplicate.body.code, "INTENT_ALREADY_USED");
  const second = await request(f.app).post("/api/intents").set(auth).send({ terminalBadgeId: "TERM-001", amountLamports: 1 }).expect(201);
  const invalid = await request(f.app).post(`/api/intents/${second.body.id}/approve`).set(auth).send({ customerBadgeId: "CUST-001", intentNonce: first.body.intentNonce }).expect(409);
  assert.equal(invalid.body.code, "INVALID_NONCE");
});

test("expired intents, unauthorized access, and transaction replacement are rejected", async (t) => {
  const f = fixture(-1); t.after(() => f.store.close());
  await request(f.app).post("/api/intents").send({ terminalBadgeId: "TERM-001", amountLamports: 1 }).expect(401);
  const expired = await request(f.app).post("/api/intents").set(auth).send({ terminalBadgeId: "TERM-001", amountLamports: 1 }).expect(201);
  const response = await request(f.app).post(`/api/intents/${expired.body.id}/approve`).set(auth).send({ customerBadgeId: "CUST-001", intentNonce: expired.body.intentNonce }).expect(409);
  assert.equal(response.body.code, "INTENT_EXPIRED");

  const live = fixture(); t.after(() => live.store.close());
  const created = await request(live.app).post("/api/intents").set(auth).send({ terminalBadgeId: "TERM-001", amountLamports: 1 }).expect(201);
  await request(live.app).post(`/api/intents/${created.body.id}/approve`).set("authorization", "Bearer other-secret").send({ customerBadgeId: "CUST-001", intentNonce: created.body.intentNonce }).expect(403);
  const approved = await request(live.app).post(`/api/intents/${created.body.id}/approve`).set(auth).send({ customerBadgeId: "CUST-001", intentNonce: created.body.intentNonce }).expect(200);
  const changed = { ...approved.body.signedTransaction, rawTransaction: Buffer.from("evil").toString("base64") };
  const mismatch = await request(live.app).post(`/api/intents/${created.body.id}/submit`).set(auth).send({ signedTransaction: changed }).expect(422);
  assert.equal(mismatch.body.code, "TRANSACTION_MISMATCH");
});
