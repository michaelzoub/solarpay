import { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode";
import { request, savedApiKey } from "./api.js";

const STEPS = ["Ready", "Broadcasting", "Awaiting approval", "Signing", "Submitting", "Confirmed"];

export function App() {
  const [network, setNetwork] = useState("CONNECTING");
  const [apiKey] = useState(savedApiKey());
  const [terminalBadgeId, setTerminalBadgeId] = useState("");
  const [customerBadgeId, setCustomerBadgeId] = useState("");
  const [amountSol, setAmountSol] = useState("0.01");
  const [memo, setMemo] = useState("Coffee");
  const [intent, setIntent] = useState(null);
  const [step, setStep] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [remaining, setRemaining] = useState(0);
  const [setupRole, setSetupRole] = useState("customer");
  const [badges, setBadges] = useState([]);
  const [setupMessage, setSetupMessage] = useState("");
  const [setupBusy, setSetupBusy] = useState(false);
  const [setupStage, setSetupStage] = useState(0);
  const [syncedBadge, setSyncedBadge] = useState(null);
  const [balance, setBalance] = useState(null);
  const [qrCode, setQrCode] = useState("");
  const [syncBusy, setSyncBusy] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setRemaining(intent ? Math.max(0, Math.ceil((intent.expiresAt - Date.now()) / 1000)) : 0), 250);
    return () => clearInterval(timer);
  }, [intent]);

  useEffect(() => {
    fetch("/api/health").then((response) => response.json()).then((health) => setNetwork(health.solanaMode === "mock" ? "MOCK" : "DEVNET")).catch(() => setNetwork("OFFLINE"));
    loadBadges();
  }, []);

  async function loadBadges() {
    try {
      const loaded = (await request("/badges", {}, apiKey)).badges;
      setBadges(loaded);
      const merchant = loaded.find((badge) => badge.role === "merchant");
      const customer = loaded.find((badge) => badge.role === "customer");
      if (merchant) setTerminalBadgeId((current) => current || merchant.badgeId);
      if (customer) setCustomerBadgeId((current) => current || customer.badgeId);
    }
    catch (reason) { setSetupMessage(reason.message); }
  }

  async function setupBadge() {
    setSetupBusy(true); setSetupMessage(""); setSetupStage(Math.max(setupStage, 1));
    try {
      const created = await request("/badges", { method: "POST", body: JSON.stringify({ role: setupRole }) }, apiKey);
      setSetupStage(2);
      if (created.role === "merchant") setTerminalBadgeId(created.badgeId); else setCustomerBadgeId(created.badgeId);
      await loadBadges();
      await syncBadge({ badgeId: created.badgeId, role: created.role, solanaAddress: created.publicKey });
      await downloadPersonalizedApp(created);
      setSetupStage(3);
      setSetupMessage(`${created.role === "customer" ? "Payer" : "Merchant"} profile and app are ready.`);
    } catch (reason) { setSetupMessage(reason.message); }
    finally { setSetupBusy(false); }
  }

  async function downloadPersonalizedApp(badge) {
    const response = await fetch(`/api/badges/${badge.badgeId}/app`, { headers: { authorization: `Bearer ${apiKey}` } });
    if (!response.ok) throw new Error("Could not create the personalized badge app");
    const blobUrl = URL.createObjectURL(await response.blob());
    const link = document.createElement("a");
    link.href = blobUrl; link.download = `solarpay-${badge.role}-${badge.badgeId}.lua`; link.click();
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  }

  async function downloadDiagnostics() {
    try {
      const server = await request("/diagnostics", {}, apiKey);
      const report = { ...server, client: { page: location.href, networkLabel: network, userAgent: navigator.userAgent } };
      const blobUrl = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: "application/json" }));
      const link = document.createElement("a");
      link.href = blobUrl; link.download = `solarpay-diagnostics-${new Date().toISOString().replace(/[:.]/g, "-")}.json`; link.click();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
    } catch (reason) { setError(`Diagnostics export failed: ${reason.message}`); }
  }

  async function syncBadge(badge) {
    setSyncedBadge(badge); setBalance(null); setQrCode(""); setSyncBusy(true); setSetupMessage("");
    try {
      const info = await request(`/badges/${badge.badgeId}/balance`, {}, apiKey);
      setBalance(info);
      if (badge.role === "customer") setQrCode(await QRCode.toDataURL(`solana:${badge.solanaAddress}`, { width: 260, margin: 1, color: { dark: "#21152f", light: "#ffffff" } }));
    } catch (reason) { setSetupMessage(reason.message); }
    finally { setSyncBusy(false); }
  }

  const lamports = useMemo(() => Math.round(Number(amountSol) * 1_000_000_000), [amountSol]);

  async function createPayment(event) {
    event.preventDefault();
    setBusy(true); setError(""); setIntent(null);
    try {
      const created = await request("/intents", { method: "POST", body: JSON.stringify({ terminalBadgeId, amountLamports: lamports, memo }) }, apiKey);
      setIntent(created); setStep(1);
      await delay(450); setStep(2);
    } catch (reason) { setError(reason.message); setStep(0); }
    finally { setBusy(false); }
  }

  async function approve() {
    if (!intent) return;
    setBusy(true); setError(""); setStep(3);
    try {
      const approval = await request(`/intents/${intent.id}/approve`, { method: "POST", body: JSON.stringify({ customerBadgeId, intentNonce: intent.intentNonce }) }, apiKey);
      setStep(4);
      const submitted = await request(`/intents/${intent.id}/submit`, { method: "POST", body: JSON.stringify({ signedTransaction: approval.signedTransaction }) }, apiKey);
      setIntent(submitted.intent); setStep(5);
    } catch (reason) { setError(reason.message); }
    finally { setBusy(false); }
  }

  function reset() { setIntent(null); setError(""); setStep(0); }

  return <main className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="mark"><span>S</span></div><div><h1>SolarPay</h1><p>Badge payments</p></div></div>
      <div className="top-actions"><button className="icon-button" aria-label="Download diagnostics" title="Download diagnostics" onClick={downloadDiagnostics}>↓</button><div className="network"><i /> {network}</div></div>
    </header>
    <nav className="tabs" aria-label="Primary navigation"><button>Overview</button><button className="active">Payments</button><button>Settings</button></nav>

    <div className="content">
      <section className="page-heading">
        <div><p className="breadcrumb">SOLARPAY / MERCHANT CHECKOUT</p><h2>Badge checkout</h2><p>Set up customer wallets, create a payment intent, and settle it on Solana devnet.</p></div>
        <div className="security-pill"><span>✓</span><div><b>Secure signing</b><small>Keys stay on the backend</small></div></div>
      </section>

      <section className="hero">
        <div className="hero-orb one" /><div className="hero-orb two" />
        <div className="hero-content"><span>POWERED BY SOLANA</span><h3>Simple payments,<br />made for badges.</h3><p>Fast devnet checkout with encrypted wallet custody and one-tap customer approval.</p></div>
        <div className="hero-stat"><small>NETWORK</small><b>{network}</b><span>Ready for checkout</span></div>
      </section>

    <section className="panel setup">
      <div className="panel-title"><span>Set up a badge</span><small>SYNC + PROFILE + APP</small></div>
      <div className="setup-grid">
        <div className="setup-flow">
          <a className="official-sync" href="https://my.hackthenorth.com/badge/sync" target="_blank" rel="noreferrer" onClick={() => setSetupStage(1)}><span>1</span><div><b>Connect & Sync badge</b><small>Official Hack the North badge setup</small></div><i>↗</i></a>
          <div className="flow-divider"><span>THEN CREATE ITS SOLARPAY PROFILE</span></div>
          <div className="role-switch"><button type="button" className={setupRole === "customer" ? "selected" : ""} onClick={() => { setSetupRole("customer"); setSetupStage((current) => Math.min(current, 1)); }}>Payer</button><button type="button" className={setupRole === "merchant" ? "selected" : ""} onClick={() => { setSetupRole("merchant"); setSetupStage((current) => Math.min(current, 1)); }}>Merchant</button></div>
          <div className="setup-intro"><span>{setupRole === "customer" ? "◎" : "↗"}</span><div><b>{setupRole === "customer" ? "Create a payer" : "Create a merchant terminal"}</b><p>{setupRole === "customer" ? "Creates a wallet, payer profile, and personalized app containing its public address." : "Creates a receiving wallet, merchant profile, and personalized terminal app."}</p></div></div>
          <button className="primary" onClick={setupBadge} disabled={setupBusy}>{setupBusy ? "Creating profile…" : `2  Create ${setupRole === "customer" ? "payer" : "merchant"} profile & app`}</button>
          {setupStage === 3 && <div className="install-ready"><span>✓</span><div><b>Personalized app downloaded</b><small>Import the file, then use Connect → Push.</small></div></div>}
          {setupStage === 3 && <a className="ide-link" href="https://badge.hackthenorth.com/ide/" target="_blank" rel="noreferrer">3&nbsp;&nbsp; Open Custom Apps IDE →</a>}
          {setupMessage && <p className="setup-message">{setupMessage}</p>}
        </div>
        <div className="registry-list">
          <div className="registry-heading"><b>Your badges</b><button onClick={() => loadBadges()}>Refresh</button></div>
          {badges.length === 0 ? <div className="empty-registry">Set up your first payer or merchant badge.</div> : badges.map((badge) => <button type="button" className={`mapping ${syncedBadge?.badgeId === badge.badgeId ? "synced" : ""}`} key={badge.badgeId} onClick={() => syncBadge(badge)}><span className={`role ${badge.role}`}>{badge.role === "customer" ? "PAYER" : "MERCHANT"}</span><b>{badge.badgeId}</b><code>{badge.solanaAddress}</code><span className="sync-label">{syncedBadge?.badgeId === badge.badgeId ? "ACTIVE" : "VIEW"}</span></button>)}
        </div>
      </div>
    </section>

    <section className={`panel synced-card ${syncedBadge?.role || "empty"}`}>
      {!syncedBadge ? <div className="sync-empty"><span>⌁</span><div><b>No badge synced</b><p>Select a registered merchant or payer to see its wallet information.</p></div></div> : <>
        <div className="synced-copy">
          <p className="synced-eyebrow">{syncedBadge.role === "customer" ? "PAYER BADGE" : "MERCHANT TERMINAL"} · SYNCED</p>
          <h3>{syncedBadge.badgeId}</h3>
          <p>{syncedBadge.role === "customer" ? "This payer can approve nearby payment requests. Scan the QR code to fund its devnet wallet." : "This merchant receives approved badge payments at the address below."}</p>
          <div className="wallet-line"><span>SOLANA ADDRESS</span><code>{syncedBadge.solanaAddress}</code></div>
          <div className="balance-block"><span>{syncedBadge.role === "customer" ? "AVAILABLE BALANCE" : "RECEIVED BALANCE"}</span><strong>{syncBusy || !balance ? "—" : `${balance.sol.toLocaleString(undefined, { maximumFractionDigits: 9 })} SOL`}</strong><small>{balance ? `${balance.lamports.toLocaleString()} lamports · ${network}` : "Loading balance…"}</small></div>
        </div>
        {syncedBadge.role === "customer" ? <div className="qr-panel">{qrCode ? <img src={qrCode} alt={`QR code for ${syncedBadge.solanaAddress}`} /> : <div className="qr-loading">Generating QR…</div>}<b>Fund payer wallet</b><small>Solana payment address</small></div> : <div className="merchant-panel"><span>◎</span><b>Ready to receive</b><small>Use this terminal badge in Merchant checkout below.</small><button onClick={() => setTerminalBadgeId(syncedBadge.badgeId)}>Use for checkout</button></div>}
      </>}
    </section>

    <section className="layout">
      <div className="panel checkout">
        <div className="panel-title"><span>Merchant checkout</span><small>{terminalBadgeId ? "READY" : "SET UP MERCHANT"}</small></div>
        <form onSubmit={createPayment}>
          <div className="device-row"><span>Merchant terminal</span><b>{terminalBadgeId || "Not set up"}</b><i className={terminalBadgeId ? "online" : ""} /></div>
          <div className="device-row"><span>Payer badge</span><b>{customerBadgeId || "Not set up"}</b><i className={customerBadgeId ? "online" : ""} /></div>
          <label>Amount<div className="amount"><span>◎</span><input type="number" min="0.000000001" step="0.000000001" value={amountSol} onChange={(e) => setAmountSol(e.target.value)} required /><b>SOL</b></div></label>
          <label>Memo<input value={memo} onChange={(e) => setMemo(e.target.value)} maxLength={64} /></label>
          <button className="primary" disabled={busy || !!intent || !terminalBadgeId || !customerBadgeId}>{busy && !intent ? "Creating…" : terminalBadgeId && customerBadgeId ? "Send to terminal" : "Set up both badges first"}</button>
        </form>
      </div>

      <div className="panel payment-state">
        <div className="panel-title"><span>Payment status</span><small>{intent ? `Intent ${intent.id}` : "No active intent"}</small></div>
        <ol className="steps">{STEPS.map((name, index) => <li key={name} className={index < step ? "done" : index === step ? "active" : ""}><span>{index < step ? "✓" : index + 1}</span><div><b>{name}</b>{index === 2 && step === 2 && intent && <small>{remaining}s remaining</small>}</div></li>)}</ol>
        {intent && step === 2 && <div className="customer-card"><p>CUSTOMER BADGE</p><strong>Merchant {intent.terminalBadgeId}</strong><h2>{(intent.amountLamports / 1e9).toFixed(4)} SOL</h2><small>{intent.memo || "Payment"} · v{intent.protocolVersion} · nonce {intent.intentNonce}</small><button className="approve" onClick={approve} disabled={busy || remaining === 0}>A &nbsp; Approve on mock badge</button></div>}
        {step === 5 && intent && <div className="success"><span>✓</span><div><b>Payment confirmed</b><small>{intent.signature}</small></div><button onClick={reset}>New payment</button></div>}
        {error && <div className="error"><b>Payment stopped</b><span>{error}</span><button onClick={reset}>Reset</button></div>}
      </div>
    </section>
    <footer><span>Private keys stay encrypted on the backend</span><span>Mock serial + radio adapters</span><span>Replay-safe intents</span></footer>
    </div>
  </main>;
}

function delay(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
