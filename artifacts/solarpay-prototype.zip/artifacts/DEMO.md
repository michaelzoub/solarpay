# SolarPay demo

SolarPay is a Solana devnet prototype for nearby badge payments. A merchant laptop creates a short-lived payment request, a payer approves it from a Hacker Badge, and the backend signs without exposing private keys.

## What to show

1. Open the SolarPay website.
2. Use the official **Connect & Sync badge** link to provision the hardware.
3. Choose **Payer** or **Merchant** and create the profile and personalized Lua app.
4. Import the downloaded app into the Hacker Badge Custom Apps IDE and use **Connect → Push**.
5. Select the synced payer to show its public wallet QR and balance.
6. Create a merchant checkout and approve it with **A** on the payer badge or the mock badge.
7. Show the confirmed mock or devnet transaction.

## Run locally

```sh
npm install
npm run dev
```

Open `http://localhost:5173`.

Run verification with:

```sh
npm run check
```

## Share diagnostics

Use the download button in the website header to export a sanitized diagnostics JSON file. It includes runtime mode, database migration versions, profile counts, payment-state counts, server uptime, and browser context. It excludes private keys, authentication secrets, payment nonces, and wallet mappings.

For a physical badge failure, also copy the Badge IDE console lines around the error and note whether the launcher entry was **SolarPay Customer** or **SolarPay Terminal**. Do not share environment files, private keys, or complete database files.

## Security model

- Badges receive only a profile identifier and public Solana address.
- Private keys remain encrypted on the backend.
- Payment amounts use integer lamports.
- Intents expire and use one-time nonces.
- Submitted transaction bytes must match the transaction signed by the backend.

## Hardware boundary

The official Hack the North page performs **Connect → Sync** to provision a badge. The Custom Apps IDE performs **Connect → Push** to install the personalized SolarPay app. The documented badge Lua API does not expose the IDE's USB upload protocol to third-party websites.
