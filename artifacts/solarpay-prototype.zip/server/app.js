import express from "express";
import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { PublicKey } from "@solana/web3.js";
import path from "node:path";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { adminAuth, laptopAuth } from "./auth.js";
import { intentPacket } from "./protocol.js";

const badgeId = z.string().regex(/^[A-Za-z0-9_-]{1,16}$/);
const nonce = z.string().regex(/^[A-Za-z0-9_-]{8,16}$/);

export function createApp({ config, store, solana }) {
  const app = express();
  app.use(express.json({ limit: "32kb" }));
  app.get("/api/health", (_req, res) => res.json({ ok: true, solanaMode: config.solanaMode }));
  app.get("/api/badge-apps/:role", (req, res) => {
    const filename = req.params.role === "merchant" ? "terminal.lua" : req.params.role === "customer" ? "customer.lua" : null;
    if (!filename) return res.status(404).json({ error: "Badge app was not found", code: "APP_NOT_FOUND" });
    const directory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../badges");
    res.download(path.join(directory, filename), `solarpay-${req.params.role}.lua`);
  });

  app.post("/api/admin/badges", adminAuth(config.adminApiKey), asyncRoute(async (req, res) => {
    const body = z.object({ badgeId, role: z.enum(["merchant", "customer"]), solanaAddress: z.string().trim().optional() }).parse(req.body);
    let wallet;
    if (body.role === "merchant" && body.solanaAddress) {
      try { wallet = { publicKey: new PublicKey(body.solanaAddress).toBase58(), secretKey: null }; }
      catch { return res.status(400).json({ error: "Merchant Solana address is invalid", code: "INVALID_SOLANA_ADDRESS" }); }
    } else {
      wallet = solana.generateWallet();
    }
    if (config.solanaMode === "mock" && body.role === "customer" && solana.fund) solana.fund(wallet.publicKey, 10_000_000_000);
    res.status(201).json(store.registerBadge({ ...body, ...wallet }));
  }));

  app.get("/api/admin/badges", adminAuth(config.adminApiKey), (_req, res) => {
    res.json({ badges: store.listBadges() });
  });

  app.get("/api/admin/badges/:badgeId/balance", adminAuth(config.adminApiKey), asyncRoute(async (req, res) => {
    const wallet = store.walletFor(req.params.badgeId);
    if (!wallet) return res.status(404).json({ error: "Registered badge was not found", code: "BADGE_NOT_FOUND" });
    const lamports = await solana.getBalance(wallet.publicKey);
    res.json({ badgeId: wallet.badgeId, role: wallet.role, solanaAddress: wallet.publicKey, lamports, sol: lamports / 1_000_000_000 });
  }));

  app.use("/api", laptopAuth(config.apiKeys));

  app.post("/api/badges", asyncRoute(async (req, res) => {
    const body = z.object({ role: z.enum(["merchant", "customer"]) }).parse(req.body);
    const prefix = body.role === "merchant" ? "TERM" : "PAY";
    const generatedBadgeId = `${prefix}-${randomBytes(3).toString("hex").toUpperCase()}`;
    const wallet = solana.generateWallet();
    if (config.solanaMode === "mock" && body.role === "customer" && solana.fund) solana.fund(wallet.publicKey, 10_000_000_000);
    res.status(201).json(store.registerBadge({ badgeId: generatedBadgeId, role: body.role, ...wallet }));
  }));

  app.get("/api/badges", (_req, res) => res.json({ badges: store.listBadges() }));

  app.get("/api/badges/:badgeId/balance", asyncRoute(async (req, res) => {
    const wallet = store.walletFor(req.params.badgeId);
    if (!wallet) return res.status(404).json({ error: "Registered badge was not found", code: "BADGE_NOT_FOUND" });
    const lamports = await solana.getBalance(wallet.publicKey);
    res.json({ badgeId: wallet.badgeId, role: wallet.role, solanaAddress: wallet.publicKey, lamports, sol: lamports / 1_000_000_000 });
  }));

  app.get("/api/badges/:badgeId/app", asyncRoute(async (req, res) => {
    const wallet = store.walletFor(req.params.badgeId);
    if (!wallet) return res.status(404).json({ error: "Registered badge was not found", code: "BADGE_NOT_FOUND" });
    const filename = wallet.role === "merchant" ? "terminal.lua" : "customer.lua";
    const directory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../badges");
    const source = await readFile(path.join(directory, filename), "utf8");
    const personalized = source.replaceAll("__SOLARPAY_BADGE_ID__", wallet.badgeId).replaceAll("__SOLARPAY_WALLET_ADDRESS__", wallet.publicKey);
    res.set("content-type", "text/x-lua; charset=utf-8");
    res.set("content-disposition", `attachment; filename="solarpay-${wallet.role}-${wallet.badgeId}.lua"`);
    res.send(personalized);
  }));

  app.get("/api/diagnostics", (_req, res) => {
    res.json({
      capturedAt: new Date().toISOString(),
      appVersion: "0.1.0",
      solanaMode: config.solanaMode,
      intentTtlSeconds: config.intentTtlSeconds,
      nodeVersion: process.version,
      uptimeSeconds: Math.floor(process.uptime()),
      database: store.diagnostics(),
      security: { walletEncryptionConfigured: !["", "development-only-encryption-key"].includes(config.encryptionKey) },
    });
  });

  app.post("/api/intents", asyncRoute(async (req, res) => {
    const body = z.object({ terminalBadgeId: badgeId, amountLamports: z.number().int().positive().max(10_000_000_000), memo: z.string().max(64).default("") }).parse(req.body);
    const merchant = store.walletFor(body.terminalBadgeId, "merchant");
    if (!merchant) return res.status(404).json({ error: "Authorized merchant badge was not found", code: "MERCHANT_NOT_FOUND" });
    const id = randomBytes(4).toString("hex");
    const intentNonce = randomBytes(8).toString("base64url");
    const expiresAt = Date.now() + config.intentTtlSeconds * 1000;
    const intent = store.createIntent({ id, terminalBadgeId: body.terminalBadgeId, merchantAddress: merchant.publicKey, amountLamports: body.amountLamports, memo: body.memo, expiresAt, intentNonce, protocolVersion: 1, createdBy: req.laptopId });
    res.status(201).json({ ...publicIntent(intent), radioPacket: intentPacket(intent, config.intentTtlSeconds, body.terminalBadgeId) });
  }));

  app.post("/api/intents/:id/approve", asyncRoute(async (req, res) => {
    const body = z.object({ customerBadgeId: badgeId, intentNonce: nonce }).parse(req.body);
    const customer = store.walletFor(body.customerBadgeId, "customer");
    if (!customer) return res.status(404).json({ error: "Authorized customer badge was not found", code: "CUSTOMER_NOT_FOUND" });
    const existing = store.getIntent(req.params.id);
    if (!existing) return res.status(404).json({ error: "Payment intent was not found", code: "INTENT_NOT_FOUND" });
    if (existing.created_by !== req.laptopId) return res.status(403).json({ error: "Intent belongs to another laptop session", code: "INTENT_OWNER_MISMATCH" });
    const claimed = store.claimApproval({ id: req.params.id, ...body, now: Date.now() });
    try {
      const signed = await solana.signTransfer({ fromWallet: customer, toAddress: claimed.merchant_address, amountLamports: claimed.amount_lamports, intentId: claimed.id });
      store.bindSignedPayload(claimed.id, transactionHash(signed.rawTransaction));
      res.json({ intent: publicIntent(claimed), signedTransaction: signed });
    } catch (error) {
      store.setSubmission(claimed.id, "failed");
      throw error;
    }
  }));

  app.post("/api/intents/:id/submit", asyncRoute(async (req, res) => {
    const body = z.object({ signedTransaction: z.object({ rawTransaction: z.string(), signature: z.string(), blockhash: z.string(), lastValidBlockHeight: z.number() }) }).parse(req.body);
    const intent = store.getIntent(req.params.id);
    if (!intent) return res.status(404).json({ error: "Payment intent was not found", code: "INTENT_NOT_FOUND" });
    if (intent.created_by !== req.laptopId) return res.status(403).json({ error: "Intent belongs to another laptop session", code: "INTENT_OWNER_MISMATCH" });
    if (intent.status !== "signed") return res.status(409).json({ error: "Payment is not ready for submission", code: "INVALID_STATE" });
    if (!intent.signed_payload_hash || intent.signed_payload_hash !== transactionHash(body.signedTransaction.rawTransaction)) {
      return res.status(422).json({ error: "Submitted transaction does not match the backend-signed payment", code: "TRANSACTION_MISMATCH" });
    }
    store.setSubmission(intent.id, "submitted");
    try {
      const signature = await solana.submitAndConfirm(body.signedTransaction);
      res.json({ intent: publicIntent(store.setSubmission(intent.id, "confirmed", signature)) });
    } catch (error) {
      store.setSubmission(intent.id, "failed");
      throw error;
    }
  }));

  app.get("/api/intents/:id", (req, res) => {
    const intent = store.getIntent(req.params.id);
    if (!intent || intent.created_by !== req.laptopId) return res.status(404).json({ error: "Payment intent was not found", code: "INTENT_NOT_FOUND" });
    res.json({ intent: publicIntent(intent) });
  });

  app.use((error, _req, res, _next) => {
    if (error instanceof z.ZodError) return res.status(400).json({ error: "Invalid request", code: "VALIDATION_ERROR", details: error.issues });
    if (!error.status || error.status >= 500) console.error(error);
    res.status(error.status || 500).json({ error: error.message || "Internal server error", code: error.code || "INTERNAL_ERROR" });
  });
  return app;
}

function publicIntent(row) {
  return {
    id: row.id, terminalBadgeId: row.terminal_badge_id, merchantAddress: row.merchant_address,
    amountLamports: row.amount_lamports, memo: row.memo, expiresAt: row.expires_at,
    intentNonce: row.intent_nonce, protocolVersion: row.protocol_version, status: row.status,
    customerBadgeId: row.customer_badge_id || undefined, signature: row.signature || undefined,
  };
}

function asyncRoute(handler) { return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next); }
function transactionHash(rawTransaction) { return createHash("sha256").update(rawTransaction).digest("hex"); }
