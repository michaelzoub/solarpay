import { Connection, Keypair, PublicKey, SystemProgram, Transaction } from "@solana/web3.js";
import { createHash } from "node:crypto";

export class DevnetSolana {
  constructor(rpcUrl) { this.connection = new Connection(rpcUrl, "confirmed"); }

  generateWallet() {
    const wallet = Keypair.generate();
    return { publicKey: wallet.publicKey.toBase58(), secretKey: Buffer.from(wallet.secretKey).toString("base64") };
  }

  async getBalance(address) { return this.connection.getBalance(new PublicKey(address), "confirmed"); }

  async signTransfer({ fromWallet, toAddress, amountLamports, intentId }) {
    const payer = Keypair.fromSecretKey(Buffer.from(fromWallet.secretKey, "base64"));
    if (payer.publicKey.toBase58() !== fromWallet.publicKey) throw new Error("Encrypted wallet key does not match its address");
    const { blockhash, lastValidBlockHeight } = await this.connection.getLatestBlockhash("confirmed");
    const transaction = new Transaction({ feePayer: payer.publicKey, blockhash, lastValidBlockHeight })
      .add(SystemProgram.transfer({ fromPubkey: payer.publicKey, toPubkey: new PublicKey(toAddress), lamports: amountLamports }));
    transaction.sign(payer);
    return {
      rawTransaction: transaction.serialize().toString("base64"),
      signature: transaction.signature.toString("base64"),
      blockhash,
      lastValidBlockHeight,
      intentId,
    };
  }

  async submitAndConfirm(signed) {
    const signature = await this.connection.sendRawTransaction(Buffer.from(signed.rawTransaction, "base64"), {
      skipPreflight: false, maxRetries: 3,
    });
    await this.connection.confirmTransaction({ signature, blockhash: signed.blockhash, lastValidBlockHeight: signed.lastValidBlockHeight }, "confirmed");
    return signature;
  }
}

export class MockSolana {
  constructor() { this.balances = new Map(); }
  generateWallet() {
    const wallet = Keypair.generate();
    return { publicKey: wallet.publicKey.toBase58(), secretKey: Buffer.from(wallet.secretKey).toString("base64") };
  }
  fund(address, lamports) { this.balances.set(address, lamports); }
  async getBalance(address) { return this.balances.get(address) || 0; }
  async signTransfer({ fromWallet, toAddress, amountLamports, intentId }) {
    const available = this.balances.get(fromWallet.publicKey) ?? 10_000_000_000;
    if (available < amountLamports) throw Object.assign(new Error("Customer wallet has insufficient funds"), { code: "INSUFFICIENT_FUNDS", status: 422 });
    const payload = Buffer.from(JSON.stringify({ from: fromWallet.publicKey, to: toAddress, amountLamports, intentId })).toString("base64");
    return { rawTransaction: payload, signature: createHash("sha256").update(payload).digest("base64"), blockhash: "mock", lastValidBlockHeight: 1 };
  }
  async submitAndConfirm(signed) {
    const transfer = JSON.parse(Buffer.from(signed.rawTransaction, "base64").toString("utf8"));
    const available = this.balances.get(transfer.from) ?? 10_000_000_000;
    if (available < transfer.amountLamports) throw new Error("Insufficient mock balance at submission");
    this.balances.set(transfer.from, available - transfer.amountLamports);
    this.balances.set(transfer.to, (this.balances.get(transfer.to) || 0) + transfer.amountLamports);
    return `mock-${createHash("sha256").update(signed.rawTransaction).digest("hex").slice(0, 32)}`;
  }
}
